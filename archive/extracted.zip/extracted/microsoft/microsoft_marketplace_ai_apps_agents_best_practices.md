---
id: "microsoft_marketplace_ai_apps_agents_best_practices"
title: "Best practices for building AI apps and agents for Microsoft Marketplace - Marketplace publisher"
url: "https://learn.microsoft.com/en-us/partner-center/marketplace-offers/artificial-intelligence-app-agent-best-practices"
source: "Microsoft"
category: "production_operations"
captured_at: "2026-05-30T12:44:37.907Z"
byline: "britw01"
excerpt: "Learn about the best practices for building AI apps and agents."
---

# Best practices for building AI apps and agents for Microsoft Marketplace - Marketplace publisher

This article presents best practices for building AI apps and agents that you will publish on Microsoft Marketplace. In this article you will find information about concepts like caching for performance, cost optimization, safe deployment strategies, and automated CI validation.

## Modular prompt and model design

Use a **modular prompt architecture** (for AI interactions) with clear versioning and _rollback_ capabilities. If your solution uses large language model prompts or chains, break them into modules/components that can be updated independently.

For example, separate prompt sections for different functions (one for summarizing, one for answering FAQs, etc.). Manage these prompts (and any ML model configurations) in a version control system just like code. This way, if you discover a prompt tweak degraded performance, you can quickly roll back to a previous version. Also maintain a changelog of prompt/model versions deployed. Treat your AI behavior as an evolving asset - version "1.0" of your agent's brain vs "1.1" etc. This practice reduces risk when you improve the AI and provides traceability for any changes made (important for debugging and for compliance, since you might need to explain what changed if an issue arises).

## Caching for performance

Implement smart **caching strategies** to improve performance and lower costs. Many AI solutions can benefit from:

-   **Semantic caching**: Caching the results of expensive AI queries. For instance, if the same question or document analysis is requested multiple times, cache the answer so the model isn't called repeatedly. Use embeddings to detect "similar" queries that might reuse an answer
-   **Retrieval cache**: If your agent retrieves information from a database or cognitive search, cache those retrieval results for a short time (assuming the underlying data doesn't change frequently) to avoid constant re-querying
-   **Standard web caching**: Content Delivery Networks (CDNs) for static content, HTTP response caching where applicable

Also consider caching partial computations (like intermediate results in a multi-step reasoning process). Monitor the cache hit rates and adjust as needed. Be mindful to invalidate caches when underlying data updates, to avoid stale answers. Effective caching can drastically reduce API calls to models (saving costs on per-call charges) and speed up responses for the user. Just ensure caching doesn't introduce wrong data serving - when in doubt, err on the side of fresh data for critical info.

## API resilience

Build **resiliency** into every external API or model call. This includes monitoring the AI model endpoints (like Azure OpenAI service calls), any third-party services, and even the Marketplace APIs:

-   **Use retry policies**: For transient failures (with exponential backoff delays)
-   **Implement circuit breakers**: If an external service is consistently failing or slow, stop calling it for a short time to let it recover (and avoid hanging your entire app)
-   **Enforce rate limiting and quotas**: Ensure your own code doesn't overload either your services or external ones. If a single user somehow triggers too many requests, queue or throttle them. Also respect any rate limits of external APIs (so your agent doesn't get blocked)
-   **Graceful degradation**: If a non-critical component fails (for example, a call to a news API to enrich an answer), your agent should still respond with core functionality rather than erring out completely
-   **Test these scenarios**: Simulate an AI service outage or slow down and see that your application handles it gracefully; maybe it returns a message like "Service is busy, please retry" rather than crashing. Marketplace reviewers are known to test the robustness of solutions by inducing failure scenarios, and enterprise customers definitely expect high availability, so this effort is well spent.

## AI guardrails

Implement **AI quality guardrails** such as grounding, errant/incorrect information filtering, and tool use enforcement. In practice, this means:

-   **Always try to ground**: the AI's responses in reliable data. If your agent answers user questions, have it cite from a knowledge base or only use a provided context. If it's an action-taking agent, make sure it has the correct context before acting
-   **Hallucination filters**: Put checks on the AI's output. For example, after generating an answer, you can verify if it contains known red-flag phrases or _obviously_ incorrect information. You might maintain a list of "weasel words" ("as an AI, I ...") or "known incorrect statements" to trigger a second-pass or a safe fallback response
-   **Tool enforcement**: If your AI agent is supposed to use certain tools or follow a certain chain-of-thought (like first call an API to get data, then respond), enforce that logic in code. Don't rely solely on the model to follow instructions; use programmatic constraints. For example, if it must do a web search for every unfamiliar term, ensure your system actually does that rather than trusting the model to know when to search

These guardrails are vital for maintaining **response quality and trustworthiness**. They'll also be looked at under the lens of Responsible AI. Document them in your design (for example, "the agent refuses answers where confidence is _less than X_, or if it detects personal data in the query").

A well-guarded agent is less likely to produce harmful or nonsensical outputs to users.

## Cost optimization

Be conscious of **cost optimization** in your design - manage token usage, batch operations, and efficient use of vector databases. AI operations (especially large language model calls) can be expensive, so:

-   **Set token budgets for prompts**: Don't let prompts or outputs grow unbounded. If a user input is extremely long, consider summarizing it first. Aim to keep prompts within a size that balances completeness and cost
-   **Batch requests whenever possible**: If you need to process 100 items with AI, it could be cheaper and faster to send them in batches (if the API supports it) than one by one
-   **Optimize your vector store usage**: If using embeddings, use appropriate dimensions, only store necessary vectors, and periodically clean up unused ones. Also, cache vector search results for repeated queries as mentioned
-   **Choose the right service tiers**: maybe start with smaller model versions or lower tiers in early phases and scale up if needed

By keeping efficiency in mind, you not only reduce your cloud bill but can also pass savings or better pricing to customers. Additionally, a lean solution is often a faster solution (benefiting user experience). You might even highlight in your marketplace listing if your solution is cost-efficient ("optimized to run under minimal compute resources"), as that appeals to business decision-makers.

## Observability and monitoring

Build comprehensive **observability** into your solution - logs, traces, and dashboards that specifically track critical flows like customer activation and fulfillment events. For example:

-   **Log each subscription event**: Resolve, Activate, etc., with details like timestamp, customer ID, result, and any errors. This lets you diagnose if, say, one customer's activation failed
-   **Trace user actions through your system**: If a user asks the AI something, be able to trace how the request went through various components (perhaps using Application Insights or a similar Application Performance Monitoring (APM) tool to trace transactions)
-   **Set up dashboards for key metrics**: Number of active subscriptions, number of daily AI queries, success/failure rates of calls, average response time, etc. Also monitor the fulfillment pipeline: for example, a tile showing "Activations in last 24h: 10 succeeded, 1 failed"
-   **Implement alerts for anomalies**: For example, if any webhook call fails or if usage drops to zero (which might indicate an outage), have an alert/email to your DevOps team

By having strong monitoring, you can catch and fix issues before they become widespread, or before Microsoft tester notices them. Observability is often something startups skimp on, but for enterprise readiness, it's essential. Plus, during certification or co-sell discussions, you can impress stakeholders by demonstrating you have robust monitoring (it shows you're serious about running a reliable service)

## Automated CI validation

Integrate **automated checks** in CI for quality, security, and AI safety. This means each time you or your team makes changes and pushes code:

-   Run unit and integration tests for functionality
-   Include tests for AI outputs (if you have a deterministic way to test them, for example, using smaller dummy models or mocks for consistency) to catch any glaring issue in responses
-   Use static analysis/security scanners (like GitHub code scanning or Azure DevOps security analyzers) to find vulnerabilities early.
-   If possible, include a Responsible AI analysis step. For instance, run a batch of queries through the new build of your AI and automatically check for any toxic or incorrect outputs
-   Lint your infrastructure as code or ARM templates to ensure security best practices

By automating these checks, you reduce human error and ensure each build maintains a baseline of quality. It's easier to enforce good practices continuously than to scramble right before publishing to fix things. Moreover, if you document these CI/CD practices, it gives Microsoft confidence that you'll keep the app in good shape after it's listed (they often care about ongoing compliance, not just one-time). Continuous integration with quality gates is a hallmark of modern software engineering.

## Safe deployment strategies

Use deployment strategies like **blue/green** deployments or ringed (staged) rollouts for updates to your AI agent. When you update your solution (especially the AI or prompt logic), don't just replace the running version for all users at once without testing. Instead:

-   **Blue/green**: Have two production environments (blue and green). Deploy the new version (green) while the old (blue) is still running. Switch a test tenant or a small subset of traffic to green and observe. If all looks good, gradually switch all traffic to green. If something goes wrong, you can quickly revert to blue (the old stable version)
-   **Ringed deployments**: Introduce the new version to a limited audience first. For example, only your own company's tenant or a friendly early adopter gets version 2.0, while everyone else stays on version 1.0. Monitor outcomes, then expand the ring to more tenants if no issues, until eventually all are migrated

These approaches are especially useful in AI because changes in model behavior can be unpredictable. By rolling out cautiously, you minimize impact from any regressions. Also, consider feature flags to turn on/off new AI features gradually. The Marketplace doesn't dictate your deployment method, but reliability and continuity for customers is key. Also, if something like a **major model update** is planned, coordinate it with your support and possibly notify customers via release notes (see **Templates** section on release notes). In short, have a **backout plan** for any change.

## Next step
