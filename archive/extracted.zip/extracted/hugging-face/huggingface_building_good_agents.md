---
id: "huggingface_building_good_agents"
title: "Building good agents · Hugging Face"
url: "https://huggingface.co/docs/smolagents/tutorials/building_good_agents"
source: "Hugging Face"
category: "framework_docs"
captured_at: "2026-05-30T12:44:46.019Z"
byline: ""
excerpt: "We’re on a journey to advance and democratize artificial intelligence through open source and open science."
---

# Building good agents · Hugging Face

There’s a world of difference between building an agent that works and one that doesn’t. How can we build agents that fall into the former category? In this guide, we’re going to talk about best practices for building agents.

> If you’re new to building agents, make sure to first read the [intro to agents](https://huggingface.co/docs/smolagents/conceptual_guides/intro_agents) and the [guided tour of smolagents](https://huggingface.co/docs/smolagents/guided_tour).

### [](#the-best-agentic-systems-are-the-simplest-simplify-the-workflow-as-much-as-you-can)The best agentic systems are the simplest: simplify the workflow as much as you can

Giving an LLM some agency in your workflow introduces some risk of errors.

Well-programmed agentic systems have good error logging and retry mechanisms anyway, so the LLM engine has a chance to self-correct their mistake. But to reduce the risk of LLM error to the maximum, you should simplify your workflow!

Let’s revisit the example from the [intro to agents](https://huggingface.co/docs/smolagents/conceptual_guides/intro_agents): a bot that answers user queries for a surf trip company. Instead of letting the agent do 2 different calls for “travel distance API” and “weather API” each time they are asked about a new surf spot, you could just make one unified tool “return\_spot\_information”, a function that calls both APIs at once and returns their concatenated outputs to the user.

This will reduce costs, latency, and error risk!

The main guideline is: Reduce the number of LLM calls as much as you can.

This leads to a few takeaways:

-   Whenever possible, group 2 tools in one, like in our example of the two APIs.
-   Whenever possible, logic should be based on deterministic functions rather than agentic decisions.

### [](#improve-the-information-flow-to-the-llm-engine)Improve the information flow to the LLM engine

Remember that your LLM engine is like an _intelligent_ robot, trapped into a room with the only communication with the outside world being notes passed under a door.

It won’t know of anything that happened if you don’t explicitly put that into its prompt.

So first start with making your task very clear! Since an agent is powered by an LLM, minor variations in your task formulation might yield completely different results.

Then, improve the information flow towards your agent in tool use.

Particular guidelines to follow:

-   Each tool should log (by simply using `print` statements inside the tool’s `forward` method) everything that could be useful for the LLM engine.
    -   In particular, logging detail on tool execution errors would help a lot!

For instance, here’s a tool that retrieves weather data based on location and date-time:

First, here’s a poor version:

import datetime
from smolagents import tool

def get\_weather\_report\_at\_coordinates(coordinates, date\_time):
    
    return \[28.0, 0.35, 0.85\]

def convert\_location\_to\_coordinates(location):
    
    return \[3.3, -42.0\]

@tool
def get\_weather\_api(location: str, date\_time: str) -> str:
    """
    Returns the weather report.

    Args:
        location: the name of the place that you want the weather for.
        date\_time: the date and time for which you want the report.
    """
    lon, lat = convert\_location\_to\_coordinates(location)
    date\_time = datetime.strptime(date\_time)
    return str(get\_weather\_report\_at\_coordinates((lon, lat), date\_time))

Why is it bad?

-   there’s no precision of the format that should be used for `date_time`
-   there’s no detail on how location should be specified.
-   there’s no logging mechanism trying to make explicit failure cases like location not being in a proper format, or date\_time not being properly formatted.
-   the output format is hard to understand

If the tool call fails, the error trace logged in memory can help the LLM reverse engineer the tool to fix the errors. But why leave it with so much heavy lifting to do?

A better way to build this tool would have been the following:

@tool
def get\_weather\_api(location: str, date\_time: str) -> str:
    """
    Returns the weather report.

    Args:
        location: the name of the place that you want the weather for. Should be a place name, followed by possibly a city name, then a country, like "Anchor Point, Taghazout, Morocco".
        date\_time: the date and time for which you want the report, formatted as '%m/%d/%y %H:%M:%S'.
    """
    lon, lat = convert\_location\_to\_coordinates(location)
    try:
        date\_time = datetime.strptime(date\_time)
    except Exception as e:
        raise ValueError("Conversion of \`date\_time\` to datetime format failed, make sure to provide a string in format '%m/%d/%y %H:%M:%S'. Full trace:" + str(e))
    temperature\_celsius, risk\_of\_rain, wave\_height = get\_weather\_report\_at\_coordinates((lon, lat), date\_time)
    return f"Weather report for {location}, {date\_time}: Temperature will be {temperature\_celsius}°C, risk of rain is {risk\_of\_rain\*100:.0f}%, wave height is {wave\_height}m."

In general, to ease the load on your LLM, the good question to ask yourself is: “How easy would it be for me, if I was dumb and using this tool for the first time ever, to program with this tool and correct my own errors?“.

### [](#give-more-arguments-to-the-agent)Give more arguments to the agent

To pass some additional objects to your agent beyond the simple string describing the task, you can use the `additional_args` argument to pass any type of object:

from smolagents import CodeAgent, InferenceClientModel

model\_id = "meta-llama/Llama-3.3-70B-Instruct"

agent = CodeAgent(tools=\[\], model=InferenceClientModel(model\_id=model\_id), add\_base\_tools=True)

agent.run(
    "Why does Mike not know many people in New York?",
    additional\_args={"mp3\_sound\_file\_url":'https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/transformers/recording.mp3'}
)

For instance, you can use this `additional_args` argument to pass images or strings that you want your agent to leverage.

## [](#how-to-debug-your-agent)How to debug your agent

### [](#1-use-a-stronger-llm)1\. Use a stronger LLM

In an agentic workflows, some of the errors are actual errors, some other are the fault of your LLM engine not reasoning properly. For instance, consider this trace for an `CodeAgent` that I asked to create a car picture:

\==================================================================================================== New task ====================================================================================================
Make me a cool car picture
──────────────────────────────────────────────────────────────────────────────────────────────────── New step ────────────────────────────────────────────────────────────────────────────────────────────────────
Agent is executing the code below: ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
image\_generator(prompt="A cool, futuristic sports car with LED headlights, aerodynamic design, and vibrant color, high-res, photorealistic")
──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

Last output from code snippet: ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
/var/folders/6m/9b1tts6d5w960j80wbw9tx3m0000gn/T/tmpx09qfsdd/652f0007-3ee9-44e2-94ac-90dae6bb89a4.png
Step 1:

- Time taken: 16.35 seconds
- Input tokens: 1,383
- Output tokens: 77
──────────────────────────────────────────────────────────────────────────────────────────────────── New step ────────────────────────────────────────────────────────────────────────────────────────────────────
Agent is executing the code below: ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
final\_answer("/var/folders/6m/9b1tts6d5w960j80wbw9tx3m0000gn/T/tmpx09qfsdd/652f0007-3ee9-44e2-94ac-90dae6bb89a4.png")
──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
Print outputs:

Last output from code snippet: ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
/var/folders/6m/9b1tts6d5w960j80wbw9tx3m0000gn/T/tmpx09qfsdd/652f0007-3ee9-44e2-94ac-90dae6bb89a4.png
Final answer:
/var/folders/6m/9b1tts6d5w960j80wbw9tx3m0000gn/T/tmpx09qfsdd/652f0007-3ee9-44e2-94ac-90dae6bb89a4.png

The user sees, instead of an image being returned, a path being returned to them. It could look like a bug from the system, but actually the agentic system didn’t cause the error: it’s just that the LLM brain did the mistake of not saving the image output into a variable. Thus it cannot access the image again except by leveraging the path that was logged while saving the image, so it returns the path instead of an image.

The first step to debugging your agent is thus “Use a more powerful LLM”. Alternatives like `Qwen2/5-72B-Instruct` wouldn’t have made that mistake.

### [](#2-provide-more-information-or-specific-instructions)2\. Provide more information or specific instructions

You can also use less powerful models, provided you guide them more effectively.

Put yourself in the shoes of your model: if you were the model solving the task, would you struggle with the information available to you (from the system prompt + task formulation + tool description) ?

Would you need detailed instructions?

-   If the instruction is to always be given to the agent (as we generally understand a system prompt to work): you can pass it as a string under argument `instructions` upon agent initialization. _(Note: instructions are appended to the system prompt, not replacing it.)_
-   If it’s about a specific task to solve: add all these details to the task. The task could be very long, like dozens of pages.
-   If it’s about how to use specific tools: include it in the `description` attribute of these tools.

### [](#3-change-the-prompt-templates-generally-not-advised)3\. Change the prompt templates (generally not advised)

If above clarifications are not sufficient, you can change the agent’s prompt templates.

Let’s see how it works. For example, let us check the default prompt templates for the [CodeAgent](https://huggingface.co/docs/smolagents/v1.26.0/en/reference/agents#smolagents.CodeAgent) (below version is shortened by skipping zero-shot examples).

print(agent.prompt\_templates\["system\_prompt"\])

Here is what you get:

You are an expert assistant who can solve any task using code blobs. You will be given a task to solve as best you can.
To do so, you have been given access to a list of tools: these tools are basically Python functions which you can call with code.
To solve the task, you must plan forward to proceed in a series of steps, in a cycle of Thought, Code, and Observation sequences.

At each step, in the 'Thought:' sequence, you should first explain your reasoning towards solving the task and the tools that you want to use.
Then in the Code sequence you should write the code in simple Python. The code sequence must be opened with '{{code\_block\_opening\_tag}}', and closed with '{{code\_block\_closing\_tag}}'.
During each intermediate step, you can use 'print()' to save whatever important information you will then need.
These print outputs will then appear in the 'Observation:' field, which will be available as input for the next step.
In the end you have to return a final answer using the \`final\_answer\` tool.

Here are a few examples using notional tools:
---
Task: "Generate an image of the oldest person in this document."

Thought: I will proceed step by step and use the following tools: \`document\_qa\` to find the oldest person in the document, then \`image\_generator\` to generate an image according to the answer.
{{code\_block\_opening\_tag}}
answer = document\_qa(document=document, question="Who is the oldest person mentioned?")
print(answer)
{{code\_block\_closing\_tag}}
Observation: "The oldest person in the document is John Doe, a 55 year old lumberjack living in Newfoundland."

Thought: I will now generate an image showcasing the oldest person.
{{code\_block\_opening\_tag}}
image = image\_generator("A portrait of John Doe, a 55-year-old man living in Canada.")
final\_answer(image)
{{code\_block\_closing\_tag}}

---
Task: "What is the result of the following operation: 5 + 3 + 1294.678?"

Thought: I will use python code to compute the result of the operation and then return the final answer using the \`final\_answer\` tool
{{code\_block\_opening\_tag}}
result = 5 + 3 + 1294.678
final\_answer(result)
{{code\_block\_closing\_tag}}

---
Task:
"Answer the question in the variable \`question\` about the image stored in the variable \`image\`. The question is in French.
You have been provided with these additional arguments, that you can access using the keys as variables in your python code:
{'question': 'Quel est l'animal sur l'image?', 'image': 'path/to/image.jpg'}"

Thought: I will use the following tools: \`translator\` to translate the question into English and then \`image\_qa\` to answer the question on the input image.
{{code\_block\_opening\_tag}}
translated\_question = translator(question=question, src\_lang="French", tgt\_lang="English")
print(f"The translated question is {translated\_question}.")
answer = image\_qa(image=image, question=translated\_question)
final\_answer(f"The answer is {answer}")
{{code\_block\_closing\_tag}}

---
Task:
In a 1979 interview, Stanislaus Ulam discusses with Martin Sherwin about other great physicists of his time, including Oppenheimer.
What does he say was the consequence of Einstein learning too much math on his creativity, in one word?

Thought: I need to find and read the 1979 interview of Stanislaus Ulam with Martin Sherwin.
{{code\_block\_opening\_tag}}
pages = web\_search(query="1979 interview Stanislaus Ulam Martin Sherwin physicists Einstein")
print(pages)
{{code\_block\_closing\_tag}}
Observation:
No result found for query "1979 interview Stanislaus Ulam Martin Sherwin physicists Einstein".

Thought: The query was maybe too restrictive and did not find any results. Let's try again with a broader query.
{{code\_block\_opening\_tag}}
pages = web\_search(query="1979 interview Stanislaus Ulam")
print(pages)
{{code\_block\_closing\_tag}}
Observation:
Found 6 pages:
\[Stanislaus Ulam 1979 interview\](https://ahf.nuclearmuseum.org/voices/oral-histories/stanislaus-ulams-interview-1979/)

\[Ulam discusses Manhattan Project\](https://ahf.nuclearmuseum.org/manhattan-project/ulam-manhattan-project/)

(truncated)

Thought: I will read the first 2 pages to know more.
{{code\_block\_opening\_tag}}
for url in \["https://ahf.nuclearmuseum.org/voices/oral-histories/stanislaus-ulams-interview-1979/", "https://ahf.nuclearmuseum.org/manhattan-project/ulam-manhattan-project/"\]:
    whole\_page = visit\_webpage(url)
    print(whole\_page)
    print("\\n" + "="\*80 + "\\n")  # Print separator between pages
{{code\_block\_closing\_tag}}
Observation:
Manhattan Project Locations:
Los Alamos, NM
Stanislaus Ulam was a Polish-American mathematician. He worked on the Manhattan Project at Los Alamos and later helped design the hydrogen bomb. In this interview, he discusses his work at
(truncated)

Thought: I now have the final answer: from the webpages visited, Stanislaus Ulam says of Einstein: "He learned too much mathematics and sort of diminished, it seems to me personally, it seems to me his purely physics creativity." Let's answer in one word.
{{code\_block\_opening\_tag}}
final\_answer("diminished")
{{code\_block\_closing\_tag}}

---
Task: "Which city has the highest population: Guangzhou or Shanghai?"

Thought: I need to get the populations for both cities and compare them: I will use the tool \`web\_search\` to get the population of both cities.
{{code\_block\_opening\_tag}}
for city in \["Guangzhou", "Shanghai"\]:
    print(f"Population {city}:", web\_search(f"{city} population")
{{code\_block\_closing\_tag}}
Observation:
Population Guangzhou: \['Guangzhou has a population of 15 million inhabitants as of 2021.'\]
Population Shanghai: '26 million (2019)'

Thought: Now I know that Shanghai has the highest population.
{{code\_block\_opening\_tag}}
final\_answer("Shanghai")
{{code\_block\_closing\_tag}}

---
Task: "What is the current age of the pope, raised to the power 0.36?"

Thought: I will use the tool \`wikipedia\_search\` to get the age of the pope, and confirm that with a web search.
{{code\_block\_opening\_tag}}
pope\_age\_wiki = wikipedia\_search(query="current pope age")
print("Pope age as per wikipedia:", pope\_age\_wiki)
pope\_age\_search = web\_search(query="current pope age")
print("Pope age as per google search:", pope\_age\_search)
{{code\_block\_closing\_tag}}
Observation:
Pope age: "The pope Francis is currently 88 years old."

Thought: I know that the pope is 88 years old. Let's compute the result using python code.
{{code\_block\_opening\_tag}}
pope\_current\_age = 88 \*\* 0.36
final\_answer(pope\_current\_age)
{{code\_block\_closing\_tag}}

Above example were using notional tools that might not exist for you. On top of performing computations in the Python code snippets that you create, you only have access to these tools, behaving like regular python functions:
{{code\_block\_opening\_tag}}
{%- for tool in tools.values() %}
{{ tool.to\_code\_prompt() }}
{% endfor %}
{{code\_block\_closing\_tag}}

{%- if managed\_agents and managed\_agents.values() | list %}
You can also give tasks to team members.
Calling a team member works similarly to calling a tool: provide the task description as the 'task' argument. Since this team member is a real human, be as detailed and verbose as necessary in your task description.
You can also include any relevant variables or context using the 'additional\_args' argument.
Here is a list of the team members that you can call:
{{code\_block\_opening\_tag}}
{%- for agent in managed\_agents.values() %}
def {{ agent.name }}(task: str, additional\_args: dict\[str, Any\]) -> str:
    """{{ agent.description }}

    Args:
        task: Long detailed description of the task.
        additional\_args: Dictionary of extra inputs to pass to the managed agent, e.g. images, dataframes, or any other contextual data it may need.
    """
{% endfor %}
{{code\_block\_closing\_tag}}
{%- endif %}

Here are the rules you should always follow to solve your task:
1. Always provide a 'Thought:' sequence, and a '{{code\_block\_opening\_tag}}' sequence ending with '{{code\_block\_closing\_tag}}', else you will fail.
2. Use only variables that you have defined!
3. Always use the right arguments for the tools. DO NOT pass the arguments as a dict as in 'answer = wikipedia\_search({'query': "What is the place where James Bond lives?"})', but use the arguments directly as in 'answer = wikipedia\_search(query="What is the place where James Bond lives?")'.
4. For tools WITHOUT JSON output schema: Take care to not chain too many sequential tool calls in the same code block, as their output format is unpredictable. For instance, a call to wikipedia\_search without a JSON output schema has an unpredictable return format, so do not have another tool call that depends on its output in the same block: rather output results with print() to use them in the next block.
5. For tools WITH JSON output schema: You can confidently chain multiple tool calls and directly access structured output fields in the same code block! When a tool has a JSON output schema, you know exactly what fields and data types to expect, allowing you to write robust code that directly accesses the structured response (e.g., result\['field\_name'\]) without needing intermediate print() statements.
6. Call a tool only when needed, and never re-do a tool call that you previously did with the exact same parameters.
7. Don't name any new variable with the same name as a tool: for instance don't name a variable 'final\_answer'.
8. Never create any notional variables in our code, as having these in your logs will derail you from the true variables.
9. You can use imports in your code, but only from the following list of modules: {{authorized\_imports}}
10. The state persists between code executions: so if in one step you've created variables or imported modules, these will all persist.
11. Don't give up! You're in charge of solving the task, not providing directions to solve it.

{%- if custom\_instructions %}
{{custom\_instructions}}
{%- endif %}

Now Begin!

As you can see, there are placeholders like `"{{ tool.description }}"`: these will be used upon agent initialization to insert certain automatically generated descriptions of tools or managed agents.

So while you can overwrite this system prompt template by passing your custom prompt as an argument to the `system_prompt` parameter, your new system prompt can contain the following placeholders:

-   To insert tool descriptions:
    
    {%- for tool in tools.values() %}
    - {{ tool.to\_tool\_calling\_prompt() }}
    {%- endfor %}
    
-   To insert the descriptions for managed agents if there are any:
    
    {%- if managed\_agents and managed\_agents.values() | list %}
    You can also give tasks to team members.
    Calling a team member works similarly to calling a tool: provide the task description as the 'task' argument. Since this team member is a real human, be as detailed and verbose as necessary in your task description.
    You can also include any relevant variables or context using the 'additional\_args' argument.
    Here is a list of the team members that you can call:
    {%- for agent in managed\_agents.values() %}
    - {{ agent.name }}: {{ agent.description }}
    {%- endfor %}
    {%- endif %}
    
-   For `CodeAgent` only, to insert the list of authorized imports: `"{{authorized_imports}}"`

Then you can change the system prompt as follows:

agent.prompt\_templates\["system\_prompt"\] = agent.prompt\_templates\["system\_prompt"\] + "\\nHere you go!"

This also works with the [ToolCallingAgent](https://huggingface.co/docs/smolagents/v1.26.0/en/reference/agents#smolagents.ToolCallingAgent).

But generally it’s just simpler to pass argument `instructions` upon agent initialization, like:

agent = CodeAgent(tools=\[\], model=InferenceClientModel(model\_id=model\_id), instructions="Always talk like a 5 year old.")

Note that `instructions` are appended to the system prompt, not replacing it.

### [](#4-extra-planning)4\. Extra planning

We provide a model for a supplementary planning step, that an agent can run regularly in-between normal action steps. In this step, there is no tool call, the LLM is simply asked to update a list of facts it knows and to reflect on what steps it should take next based on those facts.

from smolagents import load\_tool, CodeAgent, InferenceClientModel, WebSearchTool
from dotenv import load\_dotenv

load\_dotenv()

image\_generation\_tool = load\_tool("m-ric/text-to-image", trust\_remote\_code=True)

search\_tool = WebSearchTool()

agent = CodeAgent(
    tools=\[search\_tool, image\_generation\_tool\],
    model=InferenceClientModel(model\_id="Qwen/Qwen2.5-72B-Instruct"),
    planning\_interval=3 
)

result = agent.run(
    "How long would a cheetah at full speed take to run the length of Pont Alexandre III?",
)

[Update on GitHub](https://github.com/huggingface/smolagents/blob/main/docs/source/en/tutorials/building_good_agents.md)
